package com.example.Book.Repository;

import com.example.Book.Domain.BookUser;

import org.jdbi.v3.core.mapper.RowMapper;
import org.jdbi.v3.core.statement.StatementContext;

import javax.swing.tree.TreePath;
import java.sql.ResultSet;
import java.sql.SQLException;

public class BookUserMapper implements RowMapper<BookUser> {

    @Override
    public BookUser map(ResultSet rs, StatementContext ctx) throws SQLException {
        BookUser bookUser = new BookUser();
        bookUser.setBookUserId(rs.getInt("uid"));
        bookUser.setBookUserName(rs.getString("uname"));
        bookUser.setBookUserEmail(rs.getString("uemail"));
        bookUser.setBookUserPassword(rs.getString("upassword"));
        bookUser.setAppName(rs.getString("appname"));
        bookUser.setRole(rs.getString("role"));
        return bookUser;
    }
}
