package com.example.Book.Config;

import jakarta.annotation.Resource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.EnableGlobalAuthentication;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.csrf.CookieCsrfTokenRepository;


@Configuration
//@EnableGlobalMethodSecurity(prePostEnabled = true)
public class BookSecurityConfig {

//    Basic  Authentication
//    Run fast but not usefull (We can't logout it. Each request pass the username and password in Authentication tab(Postman).)
//    @Bean
//    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception{
//        http.authorizeRequests()
//                .anyRequest()
//                .authenticated()
//                .and()
//                .httpBasic();
//
//        return http.build();
//    }

//    Create the own user inMemory not in database
//    Without password Encoder it not work
//    it required to implement UserDetailsService interface.
//    @Resource
//    private  UserDetailsService userDetailsService;
//
//    @Bean
//    public DaoAuthenticationProvider authenticationProvider(){
//        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
//        authProvider.setUserDetailsService(userDetailsService);
//        return authProvider;
//    }
//
//    @Bean
//    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception{
//        http.authorizeRequests()
//                .anyRequest()
//                .authenticated()
//                .and()
//                .authenticationProvider(authenticationProvider())
//                .httpBasic();
//
//        return http.build();
//    }


//    Specify the Password Encoading Method also
    @Resource
    private  UserDetailsService userDetailsService;
    @Bean
    public DaoAuthenticationProvider authenticationProvider(){
        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
        authProvider.setUserDetailsService(userDetailsService);
        authProvider.setPasswordEncoder(passwordEncoder());
        return authProvider;
    }
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception{
        http.authorizeRequests()
                .anyRequest()
                .authenticated()
                .and()
                .authenticationProvider(authenticationProvider())
                .httpBasic();

        return http.build();
    }

//    @Bean
//    public PasswordEncoder passwordEncoder(){
////        without any encoading as a plain text
////        return NoOpPasswordEncoder.getInstance();
//
////        with BCrypt encoading
//        return new BCryptPasswordEncoder(20);
//    }


//    Spring security secure all endpoints but i want some of are not secure they can directly access without login
//    @Bean
//    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception{
//        http
////                1st way
//                .csrf(AbstractHttpConfigurer::disable)
////                2nd way
////                .csrf((csrf) -> csrf
////                        .csrfTokenRepository(CookieCsrfTokenRepository.withHttpOnlyFalse())
////                )
//                .authorizeRequests()
////                .requestMatchers("/book/public/home").permitAll()
////                .requestMatchers(HttpMethod.GET, "book/public/home").permitAll()
////                .requestMatchers("/book/public/home", "/book/login", "/book/register").permitAll()
////                .requestMatchers("/book/**").permitAll()
////                .requestMatchers("/book/public/**").permitAll()   // allows all
////                .requestMatchers("/book/public/**").hasRole("NORMAL")    // allows only Normal user
////                .requestMatchers("/book/user/**").hasRole("ADMIN")      // allows only Admin user
//                .anyRequest()
//                .authenticated()
//                .and()
//                .authenticationProvider(authenticationProvider())
//                .httpBasic();
//
//        return http.build();
//    }



//    Using Form Login Authentication
//    @Bean
//    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception{
//        http
//                .csrf(AbstractHttpConfigurer::disable)
//                .authorizeRequests()
//                .requestMatchers("/book/user/register").permitAll()
//                .requestMatchers("/book/public/**").hasRole("NORMAL")     // allows only Normal user
//                .requestMatchers("/book/user/**").hasRole("ADMIN")      // allows only Admin user
//                .anyRequest()
//                .authenticated()
//                .and()
//                .authenticationProvider(authenticationProvider())
//                .formLogin();
//
//        return http.build();
//    }

//    With database
    @Bean
    public BCryptPasswordEncoder passwordEncoder(){
        return new BCryptPasswordEncoder(20);
    }
}
