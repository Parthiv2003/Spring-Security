package com.example.Book.Controller;

import com.example.Book.Domain.BookUser;
import com.example.Book.Services.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class BookController {

    @Autowired
    BookService bookService;
    @PostMapping("book/user/register")
    public List<BookUser> registerBookUser(@RequestBody BookUser bookUser){
        bookService.registerBookUser(bookUser);
        List<BookUser> bookUserList = bookService.getAllUser();
        return bookUserList;
    }

    @GetMapping("book/user")
    public List<BookUser> getAllUser(){
        List<BookUser> bookUserList = bookService.getAllUser();
        return bookUserList;
    }

    @GetMapping("/book/user/login/email/{email}/password/{password}/appName/{appName}")
    public BookUser getUserByCredential(@PathVariable("email") String email,
                                        @PathVariable("password") String password,
                                        @PathVariable("appName") String appName){
        BookUser bookUser = bookService.getUserByCredential(email, password, appName);
        return bookUser;
    }

}
