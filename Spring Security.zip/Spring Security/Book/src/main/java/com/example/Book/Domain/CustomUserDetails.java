package com.example.Book.Domain;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.HashSet;


public class CustomUserDetails implements UserDetails {
    private BookUser bookUser;
    public CustomUserDetails(BookUser bookUser) {
        this.bookUser = bookUser;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        HashSet<SimpleGrantedAuthority> set = new HashSet<>();
        set.add(new SimpleGrantedAuthority(this.bookUser.getRole()));
        return set;
    }

    @Override
    public String getPassword() {
        return this.bookUser.getBookUserPassword();
    }

    @Override
    public String getUsername() {
        return this.bookUser.getBookUserName();
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }
}
