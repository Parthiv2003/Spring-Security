package com.example.Book.Domain;

import com.fasterxml.jackson.annotation.JsonProperty;

public class BookUser {
    @JsonProperty("uid")
    private int bookUserId;
    @JsonProperty("uname")
    private String bookUserName;

    @JsonProperty("uemail")
    private String bookUserEmail;
    @JsonProperty("upassword")
    private String bookUserPassword;

    @JsonProperty("appname")
    private String appName;

    @JsonProperty("role")
    private String role;

    public BookUser() {
    }

    public BookUser(int bookUserId, String bookUserName, String bookUserEmail, String bookUserPassword, String appName, String role) {
        this.bookUserId = bookUserId;
        this.bookUserName = bookUserName;
        this.bookUserEmail = bookUserEmail;
        this.bookUserPassword = bookUserPassword;
        this.appName = appName;
        this.role = role;
    }

    public int getBookUserId() {
        return bookUserId;
    }

    public void setBookUserId(int bookUserId) {
        this.bookUserId = bookUserId;
    }

    public String getBookUserName() {
        return bookUserName;
    }

    public void setBookUserName(String bookUserName) {
        this.bookUserName = bookUserName;
    }

    public String getBookUserEmail() {
        return bookUserEmail;
    }

    public void setBookUserEmail(String bookUserEmail) {
        this.bookUserEmail = bookUserEmail;
    }

    public String getBookUserPassword() {
        return bookUserPassword;
    }

    public void setBookUserPassword(String bookUserPassword) {
        this.bookUserPassword = bookUserPassword;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
}
