package com.example.Book.Services;

import com.example.Book.Domain.BookUser;
import com.example.Book.Repository.PublicRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PublicService {

    @Autowired
    PublicRepository publicRepository;

    public String getHomePage() {
        String text = publicRepository.getHomePage();
        return text;
    }

    public String getLoginPage() {
        String text = publicRepository.getLoginPage();
        return text;
    }

    public String getRegisterPage() {
        String text = publicRepository.getRegisterPage();
        return text;
    }
}
