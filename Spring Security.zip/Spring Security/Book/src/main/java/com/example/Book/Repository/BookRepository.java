package com.example.Book.Repository;

import com.example.Book.Domain.BookUser;
import org.jdbi.v3.core.Jdbi;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.env.Environment;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class BookRepository {

    private Jdbi jdbi;
    @Autowired
    Environment environment;

    @Autowired
    @Lazy
    private BCryptPasswordEncoder bCryptPasswordEncoder;


    public void connectToDatabase() {
        String url = environment.getProperty("spring.datasource.url");
        String username = environment.getProperty("spring.datasource.username");
        String password = environment.getProperty("spring.datasource.password");
        System.out.println("Called");
        jdbi = Jdbi.create(url, username, password);
    }

    public void registerBookUser(BookUser bookUser) {
        if(jdbi == null)
            this.connectToDatabase();

        bookUser.setBookUserPassword(bCryptPasswordEncoder.encode(bookUser.getBookUserPassword()));
        jdbi.useHandle(handle -> {
            try{

                handle.createUpdate("insert into userdata(uid, uname, uemail, upassword, appname, role) values(:bookUserId, :bookUserName, :bookUserEmail, :bookUserPassword, :appName, :role)")
                        .bindBean(bookUser)
                        .execute();
            }
            catch(Exception e){
                System.out.println("Already exist");
            }
        });
    }

    public List<BookUser> getAllUser() {
        if(jdbi == null)
            this.connectToDatabase();

        return jdbi.withHandle(handle -> {
            return handle.createQuery("Select * from userdata")
                    .map(new BookUserMapper())
                    .list();
        });
    }

    public BookUser getUserByCredential(String email, String password, String appName) {
        if(jdbi == null)
            this.connectToDatabase();

        return jdbi.withHandle(handle -> {

            BookUser bookUser = null;
            BookUser temp = null;
            try{
                List<BookUser> encryptedPassword = handle.createQuery("select * from userdata where uemail =:bookUserEmail and appname =:appName")
                        .bind("bookUserEmail",email)
                        .bind("appName", appName)
                        .map(new BookUserMapper())
                        .list();
                temp = encryptedPassword.get(0);
                System.out.println(bCryptPasswordEncoder.matches(password, temp.getBookUserPassword()));
                if(bCryptPasswordEncoder.matches(password, temp.getBookUserPassword())) {
                    List<BookUser> bookUserList = handle.createQuery("select * from userdata where uemail =:bookUserEmail and appname =:appName")
                            .bind("bookUserEmail", email)
                            .bind("appName", appName)
                            .map(new BookUserMapper())
                            .list();
                    bookUser = bookUserList.get(0);
                }
            }
            catch (Exception e){
                System.out.println("Something going wrong...");
            }
            return bookUser;
        });
    }

    public BookUser getUserByUseremail(String bookUserEmail) {
        if(jdbi == null)
            this.connectToDatabase();

        return jdbi.withHandle(handle -> {

            BookUser bookUser = null;
            try{
                List<BookUser> bookUserList =  handle.createQuery("select * from userdata where uemail =:bookUserEmail")
                        .bind("bookUserEmail",bookUserEmail)
                        .map(new BookUserMapper())
                        .list();
                bookUser = bookUserList.get(0);
            }
            catch (Exception e){
                System.out.println("Something going wrong...");
            }
            return bookUser;
        });
    }
}
