package com.example.Book.Controller;

import com.example.Book.Services.PublicService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("book/public")
public class PublicController {

    @Autowired
    PublicService publicService;
    @GetMapping("/home")
    public String getHomePage(){
        String text = publicService.getHomePage();
        return text;
    }

//    @PreAuthorize("hasRole('ADMIN')")    // Only admin can access this API for that add one annotation on config class @EnableGlobalMethodSecurity(prePostEnabled = true)
    @GetMapping("/login")
    public String getLoginPage(){
        String text = publicService.getLoginPage();
        return text;
    }

    @GetMapping("/register")
    public String getRegisterPage(){
        String text = publicService.getRegisterPage();
        return text;
    }
}
