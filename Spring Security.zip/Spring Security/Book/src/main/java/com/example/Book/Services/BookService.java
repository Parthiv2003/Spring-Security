package com.example.Book.Services;

import com.example.Book.Domain.BookUser;
import com.example.Book.Repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class BookService {

    @Autowired
    BookRepository bookRepository;

    public void registerBookUser(BookUser bookUser) {
        bookRepository.registerBookUser(bookUser);
    }

    public List<BookUser> getAllUser() {
        List<BookUser> bookUserList = bookRepository.getAllUser();
        return bookUserList;
    }

    public BookUser getUserByCredential(String email, String password, String appName) {

        BookUser bookUser = bookRepository.getUserByCredential(email, password, appName);
        return bookUser;
    }
}
