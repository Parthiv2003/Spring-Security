package com.example.Book.Repository;

import org.springframework.stereotype.Repository;

@Repository
public class PublicRepository {


    public String getHomePage() {

        return "This is Home Page";
    }

    public String getLoginPage() {
        return "This is Login Page";
    }

    public String getRegisterPage() {
        return "This is Register Page";
    }
}
