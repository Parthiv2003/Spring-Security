package com.example.Book.Services;

import com.example.Book.Domain.BookUser;
import com.example.Book.Domain.CustomUserDetails;
import com.example.Book.Repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    private BookRepository bookRepository;

//    @Override
//    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
//        if(username == null){
//            throw new UsernameNotFoundException(username);
//        }
//
////        Use only when password encoded with plain text
////        UserDetails userDetails = User.withUsername("Morkal").password("pqr").build();
//
////        Use when password encoded with Bcrypt
////        Role means which role and authority means give permission to a specific role
////        UserDetails userDetails1 = User.withUsername("Morkal").password(new BCryptPasswordEncoder().encode("pqr")).roles("NORMAL").build();
////        UserDetails userDetails2 = User.withUsername("David").password(new BCryptPasswordEncoder().encode("xyz")).roles("ADMIN").build();
////
////        List<UserDetails> userDetailsList = Arrays.asList(userDetails1, userDetails2);
////
////        return  userDetailsList
////                .stream()
////                .filter(userDetails -> userDetails.getUsername().equals(username))
////                .findFirst()
////                .orElseThrow(() -> new UsernameNotFoundException("User not found: " + username));
//
//
//    }

    @Override
    public UserDetails loadUserByUsername(String bookUserEmail) throws UsernameNotFoundException {
        BookUser bookUser = bookRepository.getUserByUseremail(bookUserEmail);
        return new CustomUserDetails(bookUser);
    }

}
